//
//  Digioh.h
//  Digioh
//
//  Created by apple on 2/3/23.
//

#import <Foundation/Foundation.h>

//! Project version number for Digioh.
FOUNDATION_EXPORT double DigiohVersionNumber;

//! Project version string for Digioh.
FOUNDATION_EXPORT const unsigned char DigiohVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Digioh/PublicHeader.h>


